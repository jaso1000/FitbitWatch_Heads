import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import { today } from 'user-activity';
import { today } from "user-activity";
import { HeartRateSensor } from "heart-rate";
import { display } from "display";

/////////////////// Date and Time//////////////////////////////
// Update the clock every minute
clock.granularity = "minutes";

// Declare the variables we need for the clock 
const Hours = document.getElementById("Hours");
const Minutes = document.getElementById("Minutes");
const DateLabel = document.getElementById("DateLabel");

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
    hours = util.zeroPad(hours);
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  Hours.text = `${hours}`;
  Minutes.text = `${mins}`;
  DateLabel.text = `${today}`;
}
//////////////////////////////////////////////////////////////////////////

////////////////////////////////Heart Rate ///////////////////////////////
// Declare the variables we need for heart rate
const HeartRate = document.getElementById("HeartRate");

if (HeartRateSensor) {
  const hrm = new HeartRateSensor();
  hrm.addEventListener("reading", () => {
    //console.log(`Current heart rate: ${hrm.heartRate}`);
    HeartRate.text = `${hrm.heartRate}`;
  });
  display.addEventListener("change", () => {
    // Automatically stop the sensor when the screen is off to conserve battery
    display.on ? hrm.start() : hrm.stop();
  });
  hrm.start();
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////// Steps ///////////////////////////////
// Declare the variables we need for steps
const MySteps = document.getElementById("MySteps");

function updateSteps() {
  let steps = (today.local.steps.toLocaleString() || 0);
  MySteps.text = `${steps}`;
  //console.log(`${steps}`);
}

//////////////////////////////////////////////////////////////////////////

//////////////////////////////////// Calories ///////////////////////////////
// Declare the variables we need for steps

const Calories = document.getElementById("Calories");

function getCalories() {
  let val = (today.adjusted.calories || 0);
  val = val > 999 ? Math.floor(val/1000) + "," + ("00"+(val%1000)).slice(-3) : val;
  
  Calories.text = `${val}`;
  //console.log(`${val}`);
}

/////////////////////////////////////////////////////////////////////////////

///////////////////////////// Distance //////////////////////////////////////
// Declare the variables we need for steps

const Distance = document.getElementById("Distance");


function getDistance() {
  let val = (today.adjusted.distance || 0) / 1000;
  
  Distance.text = `${val.toFixed(2)}`;
  //console.log(`${val.toFixed(2)}`);
}

/////////////////////////////////////////////////////////////////////////////

//////////////////////////// Active Minutes /////////////////////////////////

const ActiveMinutes = document.getElementById("ActiveMinutes");

function getActiveMinutes() {
  let val = (today.adjusted.activeMinutes || 0);
  
  ActiveMinutes.text = `${val}`;
  //console.log(`${val}`);
  
}

/////////////////////////////////////////////////////////////////////////////

////////////////////////// Randomly Select one of our head images ////////////////

const RandomImagePath = document.getElementById("RandomImagePath");

function getRandomImage(min, max) {

  let randomNum = Math.random() * (max - min) + min;
  randomNum = Math.floor(randomNum).toString();
  
  //console.log(`${randomNum}`);
  
  if (randomNum == 1) {
    RandomImagePath.href = "Images/Heads/1.png"; 
    //console.log("We dropped into 1");
  } else if (randomNum == 2) {
    RandomImagePath.href = "Images/Heads/2.png"; 
    //console.log("We dropped into 2");
  } else if (randomNum == 3) {
    RandomImagePath.href = "Images/Heads/3.png"; 
    //console.log("We dropped into 3");
  } else if (randomNum == 4) {
    RandomImagePath.href = "Images/Heads/4.png"; 
    //console.log("We dropped into 4");
  }
  else if (randomNum == 5) {
    RandomImagePath.href = "Images/Heads/5.png"; 
    //console.log("We dropped into 5");
  }
  else if (randomNum == 6) {
    RandomImagePath.href = "Images/Heads/6.png"; 
    //console.log("We dropped into 6");
  }
  else if (randomNum == 7) {
    RandomImagePath.href = "Images/Heads/7.png"; 
    //console.log("We dropped into 7");
  }
  
  //console.log(`${RandomImagePath.href}`);
  
}

/////////////////////////////////////////////////////////////////////////////

///////////////////  Update Activity Stats on screen wake ///////////////////

display.onchange = function() {
  if (display.on) {
    //console.log("ON");
    getCalories();
    updateSteps();
    getDistance();
    getActiveMinutes();
    getRandomImage(1, 8);
  }
}

/////////////////////////////////////////////////////////////////////////////